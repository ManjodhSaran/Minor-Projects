// import { navigationActions } from '@react-navigation/native'

// let navigation;

// export const setNavigation = (nav) => {
//     navigation = nav
// }

// export const navigate = (routeName, params) => {
//     navigator.dispatach(
//         navigationActions.navigate({
//             routeName,
//             params
//         })
//     )
// }