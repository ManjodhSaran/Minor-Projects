// import { makeStyles, Modal } from '@material-ui/core';
// import React, { useEffect, useState } from 'react'

// import HighlightOffIcon from '@material-ui/icons/HighlightOff';
// import { useDispatch, useSelector } from 'react-redux';
// import { selectPdfSource, resetPdfSrc } from '../../features/appSlice';

// import PDFViewer from 'pdf-viewer-reactjs'

// import { Document } from 'react-pdf';

// function getModalStyle() {
//     const top = 50;
//     const left = 50;

//     return {
//         top: `${top}%`,
//         left: `${left}%`,
//         transform: `translate(-${top}%, -${left}%)`,
//     };
// }

// const useStyles = makeStyles((theme) => ({
//     paper: {
//         position: 'absolute',
//         width: "100vw",
//         height: "100vh",
//         backgroundColor: "rgba(255, 255, 255,0.5)",
//         border: '2px solid #000',
//         boxShadow: theme.shadows[5],
//         padding: theme.spacing(2, 4, 3),
//     },
// }));

// const PdfViewer = () => {

//     const [modalStyle] = useState(getModalStyle);
//     const classes = useStyles();

//     const dispatch = useDispatch();


//     const data = useSelector(selectPdfSource);


//     const [numPages, setNumPages] = useState(null);
//     const [pageNumber, setPageNumber] = useState(1);
//     const [file, setFile] = useState(null);

//     function onDocumentLoadSuccess({ numPages }) {
//         setNumPages(numPages);
//     }

//     useEffect(() => {
//         if (data) {
//             const file2 = data.fileURL
//             const reader = new FileReader();
//             reader.addEventListener("load", () => {
//                 const result = reader.result;
//                 setFile(result)

//             });
//             reader.readAsDataURL(file2)
//         }
//     }, [data])


//     return (
//         data && <div className="">
//             <Modal open={true}>
//                 {
//                     <div style={modalStyle} className={classes.paper}>

//                         <div>
//                             <div>
//                                 <h3>{data.title}</h3>
//                                 <p>{data.file}</p>
//                                 <p>{data.subjectName}</p>
//                                 <p>{data.description}</p>
//                             </div>
//                             {/* <Document
// 										file={file}
// 										onLoadSuccess={onDocumentLoadSuccess}
// 									>
// 										<Page pageNumber={pageNumber} />
// 									</Document> */}
//                             <p>Page {pageNumber} of {numPages}</p>
//                             {/* <PDFViewer
// 								document={{
// 									url: 'https://arxiv.org/pdf/quant-ph/0410100.pdf',
// 								}}
// 							/> */}
//                         </div>

//                         <div onClick={() => dispatch(resetPdfSrc())} className="report__close">
//                             <HighlightOffIcon className="report__closeIcon" />
//                         </div>
//                     </div>
//                 }
//             </Modal>
//         </div>
//     )
// }

// export default PdfViewer
