import React, { useEffect, useState } from 'react'
import { db } from '../../../utils/firebase';
import MessageCard from './MessageCard/MessageCard';

import './Messages.css'
const Messages = ({ setActive }) => {

    const [messages, setMessages] = useState([]);

    useEffect(() => setActive("messages"), [setActive]);

    useEffect(() => {

        db
            .collection("admin")
            .doc("appData")
            .collection("contactUs")
            .orderBy("timestamp", "desc")
            .onSnapshot(snapshot =>
                setMessages(snapshot.docs.map(doc => ({
                    docID: doc.id,
                    data: doc.data()
                })))
            )

    }, []);

    return (
        <div className="messages">

            {messages.map(({ data, docID }) => <MessageCard key={docID} docID={docID} data={data} />)}

        </div>
    )
}

export default Messages
