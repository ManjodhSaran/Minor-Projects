import { Avatar } from '@material-ui/core'
import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { selectUser, showNotification } from '../../../../features/appSlice'
import { db, users } from '../../../../utils/firebase'

import './User.css'
const User = ({ user }) => {
    const appUser = useSelector(selectUser);
    const dispatch = useDispatch();

    const resetContribution = () => {
        users
            .doc(user.uid)
            .set(
                { contro: 0 },
                { merge: true }
            )
            .then(() => dispatch(showNotification(`${user.displayName}'s Contributions set to 0 `)))
    }

    const resetContro = () => {
        if (window.confirm(`Reset ${user.displayName}'s Contributions to 0. `)) {
            if (appUser.role !== 'admin') {
                if (window.prompt("pass: ") === "adminPower") {
                    resetContribution();
                } else {
                    if (window.prompt("pass(2nd attempt): ") === "adminPower") {
                        resetContribution();
                    } else {
                        window.alert("Incorrect Pass! Retry Later.");
                    }
                }
            } else {
                resetContribution();
            }
        }
    }

    const makeMod = () => {
        db
            .collection("Users")
            .doc(user.uid)
            .set(
                { role: "mod" },
                { merge: true }
            ).then(() => dispatch(showNotification(`${user.displayName} is Moderator Now. `)))
    }
    const removeMod = () => {
        db
            .collection("Users")
            .doc(user.uid)
            .set(
                { role: "user" },
                { merge: true }
            ).then(() => dispatch(showNotification(`${user.displayName} is removed from Moderator. `)))
    }



    return (
        <div className="user">
            <div className="user__containier">
                <div className="user__photo">
                    <Avatar src={user.photoURL} />
                </div>
                <div className="user__info">
                    <h4>{user.displayName}
                        {user.role === "admin" ? <span className="user__admin">Admin</span>
                            : <span className="user__role">{user.role}</span>
                        }
                    </h4>
                    <h5>{user.email}</h5>
                    {user.phoneNumber != null && <h6> {user.phoneNumber}</h6>}
                </div>
            </div>
            <div>
                {appUser && appUser.role === "admin" && (
                    user.role !== "admin" &&
                    (user.role === "mod" ?
                        <p onClick={removeMod} className="text-danger user__makeMod">Remove Mod</p>
                        :
                        <p onClick={makeMod} className="text-success user__makeMod">Make Mod</p>
                    )
                )}

            </div>
            <div className="user__mid">
                <p>{user.contro} Contributions</p>
                <p className="user__midReset" onClick={resetContro}>.reset</p>
            </div>
            <div className="user__id">
                <p>UserID:{user.uid}</p>
            </div>
        </div>
    )
}

export default User
