import { CircularProgress } from '@material-ui/core';
import React, { useEffect, useState } from 'react'
import { users } from '../../../utils/firebase';
import User from './User/User';

import './Users'
const Users = ({ setActive }) => {

    const [usersList, setUsersList] = useState([]);

    useEffect(() => {
        users.onSnapshot(snapshot =>
            setUsersList(snapshot.docs.map(doc => doc.data()))
        )

    }, [])

    useEffect(() => setActive("users"), [setActive])

    return (
        <div className="users">
            {users.length === 0 ? <CircularProgress /> : usersList.map(user => <User key={user.uid} user={user} />)}
        </div>
    )
}

export default Users
