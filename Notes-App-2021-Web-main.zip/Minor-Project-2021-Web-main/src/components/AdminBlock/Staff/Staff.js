import React, { useEffect, useState } from 'react'
import { users as usersDb } from '../../../utils/firebase';
import User from '../Users/User/User';

import './Staff'
const Staff = ({ setActive }) => {

    const [users, setUsers] = useState([]);

    useEffect(() => {
        usersDb
            .onSnapshot(snapshot =>
                setUsers(snapshot.docs.map(doc => doc.data()))
            )
    }, [])

    useEffect(() => setActive("staff"), [setActive])

    return (
        <div className="staff">
            {users.map(user => user.role !== "user" && <User key={user.uid} user={user} />)}
        </div>
    )
}

export default Staff
