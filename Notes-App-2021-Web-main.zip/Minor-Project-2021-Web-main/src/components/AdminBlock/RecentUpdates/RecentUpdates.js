import { CircularProgress } from '@material-ui/core';
import React, { useEffect, useState } from 'react'
import { db } from '../../../utils/firebase';

import './RecentUpdates.css'
const RecentUpdates = ({ setActive }) => {

    const [data, setData] = useState([]);

    useEffect(() => {
        db
            .collection("admin")
            .doc("appData")
            .collection("recents")
            .orderBy("timestamp", "desc")
            .onSnapshot(snapshot =>
                setData(snapshot.docs.map(doc => doc.data()))
            )
        setActive("recent")
    }, [])

    useEffect(() => setActive("recent"), [setActive])
    console.log(data)
    return (
        <div className="recentUpdates">
            {data ?
                data.map((doc, i) =>
                    <div key={`app__${doc.name || doc.repoName}__${i}`} className="recentUpdates__card">
                        <p className="recentUpdates__cardApp">{doc.name || doc.repoName}:  </p>
                        <div className="recentUpdates__cardMain" dangerouslySetInnerHTML={{ __html: doc.message }} />
                        <p>{doc.timestamp?.toDate()?.toDateString()}, {doc.timestamp?.toDate()?.toTimeString().substr(0, 5)}</p>
                    </div>
                )
                :
                <CircularProgress />
            }
        </div>
    )
}

export default RecentUpdates
