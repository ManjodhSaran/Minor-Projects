import React, { useEffect, useState } from 'react'
import firebase from 'firebase';
import { db, users } from './firebase';
import { useSelector } from 'react-redux';
import { selectUser } from '../features/appSlice';
const publicIp = require('public-ip');

const StoreIP = () => {

    const user = useSelector(selectUser);
    const [geo, setGeo] = useState("");
    const [IP, setIP] = useState("");

    useEffect(() => {
        try {
            (async () => {
                setIP(await publicIp.v4());
            })();
        } catch (e) { console.log(e.message) }

    }, [IP, setIP])

    useEffect(() => {
        try {
            fetch(`https://geolocation-db.com/json/0f761a30-fe14-11e9-b59f-e53803842572/${IP}`)
                .then(response => response.json())
                .then(data => setGeo(data));
        } catch (e) { console.log(e.message) }

    }, [IP])


    useEffect(() => {
        if (geo && IP) {
            if (user) {
                const ref = users.doc(user.uid).collection("userIPs").doc(IP)

                ref.get()
                    .then(doc => {
                        if (doc.exists) {
                            ref.set(
                                { visit: parseInt(doc.data().visit) + parseInt(1) },
                                { merge: true }
                            )
                        } else {
                            ref.set(
                                {
                                    IP: IP,
                                    geoLocation: geo,
                                    timestamp: firebase.firestore.FieldValue.serverTimestamp(),
                                    visit: 1
                                }
                            )
                        }
                    })

            } else {
                const ref = db.collection("IPs").doc(IP)

                ref.get()
                    .then(doc => {
                        if (doc.exists) {
                            ref.set(
                                { visit: parseInt(doc.data().visit) + 1 },
                                { merge: true }
                            )
                        } else {
                            ref.set(
                                {
                                    IP: IP,
                                    geoLocation: geo,
                                    timestamp: firebase.firestore.FieldValue.serverTimestamp(),
                                    visit: 0
                                }
                            )
                        }
                    })
            }

        }

    }, [user, IP, geo])


    return (
        <div>

        </div>
    )
}

export default StoreIP