import firebase from 'firebase'

// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyCpubGQctKi41Z8uABIeLjgVo8_C9_9lvI",
    authDomain: "gne-notes.firebaseapp.com",
    projectId: "gne-notes",
    storageBucket: "gne-notes.appspot.com",
    messagingSenderId: "937814444582",
    appId: "1:937814444582:web:23df34029ba64c36c774e7",
    measurementId: "G-Z8D7G2K3CW"
};

const firebaseApp = firebase.initializeApp(firebaseConfig);

const db = firebaseApp.firestore();
const auth = firebase.auth();
const storage = firebase.storage();
const rdb = firebase.database();
const repos = db.collection("repos");
const users = db.collection("Users");
const appData = db.collection('admin').doc("appData");

const provider = new firebase.auth.GoogleAuthProvider()

export { db, rdb, auth, storage, provider, repos, users, appData };